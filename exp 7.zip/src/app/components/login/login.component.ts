import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { UserService } from '../../services/user.service';
import { PLATFORM_ID, Inject } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  user = {
    username: '',
    password: ''
  };
  errorMessage = '';
  isLoading = false;
  private isBrowser: boolean;

  constructor(
    private router: Router, 
    private userService: UserService,
    @Inject(PLATFORM_ID) platformId: Object
  ) {
    this.isBrowser = isPlatformBrowser(platformId);
  }

  login() {
    // Reset error message
    this.errorMessage = '';
    
    // Field validation
    if (!this.user.username.trim()) {
      this.errorMessage = 'Username is required';
      return;
    }
    
    if (!this.user.password) {
      this.errorMessage = 'Password is required';
      return;
    }
    
    this.isLoading = true;
    
    // Use the MongoDB API service
    this.userService.login(this.user.username, this.user.password)
      .subscribe({
        next: (response) => {
          console.log('Login successful', response);
          this.isLoading = false;
          
          // Redirect to home page after successful login
          this.router.navigate(['/']);
        },
        error: (error) => {
          console.error('Login error', error);
          this.isLoading = false;
          
          if (error.status === 401) {
            this.errorMessage = 'Invalid username or password';
          } else if (error.status === 400) {
            this.errorMessage = error.error?.message || 'Please enter valid credentials';
          } else {
            this.errorMessage = 'An error occurred during login. Please try again.';
          }
        }
      });
  }
}
