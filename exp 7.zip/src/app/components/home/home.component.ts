import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UserService } from '../../services/user.service';
import { CartService } from '../../services/cart.service';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent implements OnInit {
  username: string = '';

  constructor(
    private userService: UserService,
    private cartService: CartService
  ) {}

  ngOnInit() {
    this.userService.currentUsername.subscribe(username => {
      this.username = username;
    });
  }

  // Add to cart functionality
  addToCart(item: any) {
    console.log('Item added to cart:', item);
    this.cartService.addToCart(item);
    alert(`${item.name} has been added to your cart!`);
  }
}
