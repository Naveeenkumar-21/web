import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { UserService } from '../../services/user.service';
import { PLATFORM_ID, Inject } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './profile.component.html',
  styleUrl: './profile.component.css'
})
export class ProfileComponent {
  user = {
    username: 'johndoe',
    fullname: 'John Doe',
    email: 'john.doe@example.com',
    dob: '1990-01-01',
    gender: 'male',
    address: '123 Main St, Anytown',
    country: 'United States',
    profilePic: 'assets/images/profile-placeholder.jpg'
  };
  
  countries = [
    'United States', 'Canada', 'United Kingdom', 'Australia', 
    'Germany', 'France', 'India', 'Japan', 'China', 'Brazil'
  ];
  
  editMode = false;
  successMessage = '';
  errorMessage = '';
  private isBrowser: boolean;
  
  constructor(
    private userService: UserService,
    @Inject(PLATFORM_ID) platformId: Object
  ) {
    this.isBrowser = isPlatformBrowser(platformId);
    
    // Check if user is logged in and update profile info
    this.userService.currentUsername.subscribe(username => {
      if (username) {
        // In a real app, you would fetch user profile from a service
        // For demo, we'll use the username from the auth service
        this.user.username = username;
        
        if (!this.isBrowser) {
          return;
        }
        
        // Try to load saved profile data
        const storedUser = localStorage.getItem('user_' + username);
        if (storedUser) {
          const userData = JSON.parse(storedUser);
          this.user.email = userData.email || this.user.email;
          
          // If profile data exists, load it
          const storedProfile = localStorage.getItem('profile_' + username);
          if (storedProfile) {
            const profileData = JSON.parse(storedProfile);
            this.user.fullname = profileData.fullname || this.user.fullname;
            this.user.dob = profileData.dob || this.user.dob;
            this.user.gender = profileData.gender || this.user.gender;
            this.user.address = profileData.address || this.user.address;
            this.user.country = profileData.country || this.user.country;
            this.user.profilePic = profileData.profilePic || this.user.profilePic;
          }
        }
      }
    });
  }
  
  toggleEditMode() {
    this.editMode = !this.editMode;
    this.successMessage = '';
    this.errorMessage = '';
  }
  
  saveProfile() {
    if (!this.isBrowser) {
      return;
    }
    
    // This would normally call a service to update the profile
    console.log('Saving profile:', this.user);
    
    // Save profile data to localStorage
    localStorage.setItem('profile_' + this.user.username, JSON.stringify({
      fullname: this.user.fullname,
      dob: this.user.dob,
      gender: this.user.gender,
      address: this.user.address,
      country: this.user.country,
      profilePic: this.user.profilePic
    }));
    
    // Mock successful update
    this.successMessage = 'Profile updated successfully!';
    this.errorMessage = '';
    this.editMode = false;
  }
  
  onFileSelected(event: any) {
    if (!this.isBrowser) {
      return;
    }
    
    const file = event.target.files[0];
    if (file) {
      // In a real application, you would upload the file to a server
      // For now, we'll just create a local URL
      const reader = new FileReader();
      reader.onload = () => {
        this.user.profilePic = reader.result as string;
      };
      reader.readAsDataURL(file);
    }
  }
}
