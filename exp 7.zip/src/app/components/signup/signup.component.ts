import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { UserService } from '../../services/user.service';
import { PLATFORM_ID, Inject } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';

@Component({
  selector: 'app-signup',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './signup.component.html',
  styleUrl: './signup.component.css'
})
export class SignupComponent {
  user = {
    username: '',
    email: '',
    password: '',
    confirmPassword: '',
    acceptTerms: false
  };
  
  errorMessage = '';
  fieldErrors: { [key: string]: string } = {};
  isLoading = false;
  private isBrowser: boolean;
  
  constructor(
    private router: Router, 
    private userService: UserService,
    @Inject(PLATFORM_ID) platformId: Object
  ) {
    this.isBrowser = isPlatformBrowser(platformId);
  }
  
  validateField(field: string): boolean {
    switch(field) {
      case 'username':
        if (!this.user.username.trim()) {
          this.fieldErrors['username'] = 'Username is required';
          return false;
        }
        delete this.fieldErrors['username'];
        return true;
      
      case 'email':
        if (!this.user.email.trim()) {
          this.fieldErrors['email'] = 'Email is required';
          return false;
        }
        
        const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
        if (!emailPattern.test(this.user.email)) {
          this.fieldErrors['email'] = 'Please enter a valid email address';
          return false;
        }
        
        delete this.fieldErrors['email'];
        return true;
      
      case 'password':
        if (!this.user.password) {
          this.fieldErrors['password'] = 'Password is required';
          return false;
        }
        
        if (this.user.password.length < 6) {
          this.fieldErrors['password'] = 'Password must be at least 6 characters long';
          return false;
        }
        
        delete this.fieldErrors['password'];
        return true;
      
      case 'confirmPassword':
        if (!this.user.confirmPassword) {
          this.fieldErrors['confirmPassword'] = 'Please confirm your password';
          return false;
        }
        
        if (this.user.password !== this.user.confirmPassword) {
          this.fieldErrors['confirmPassword'] = 'Passwords do not match';
          return false;
        }
        
        delete this.fieldErrors['confirmPassword'];
        return true;
      
      case 'acceptTerms':
        if (!this.user.acceptTerms) {
          this.fieldErrors['acceptTerms'] = 'You must accept the terms and conditions';
          return false;
        }
        
        delete this.fieldErrors['acceptTerms'];
        return true;
      
      default:
        return true;
    }
  }
  
  signup() {
    // Reset error messages
    this.errorMessage = '';
    this.fieldErrors = {};
    
    // Validate all fields
    const usernameValid = this.validateField('username');
    const emailValid = this.validateField('email');
    const passwordValid = this.validateField('password');
    const confirmPasswordValid = this.validateField('confirmPassword');
    const termsValid = this.validateField('acceptTerms');
    
    // If any validation fails, stop the submission
    if (!usernameValid || !emailValid || !passwordValid || !confirmPasswordValid || !termsValid) {
      // The individual field errors are already set
      return;
    }
    
    this.isLoading = true;
    
    // Call the API service to register the user
    this.userService.signup({
      username: this.user.username,
      email: this.user.email,
      password: this.user.password
    }).subscribe({
      next: (response) => {
        console.log('Signup successful', response);
        this.isLoading = false;
        
        // Redirect to login page
        this.router.navigate(['/login'], { 
          queryParams: { 
            newAccount: 'true',
            username: this.user.username 
          }
        });
      },
      error: (error) => {
        console.error('Signup error', error);
        this.isLoading = false;
        
        if (error.status === 400) {
          this.errorMessage = error.error?.message || 'Registration failed. Please check your information.';
          
          // Handle specific field errors if the API returns them
          if (error.error?.field) {
            this.fieldErrors[error.error.field] = error.error.message;
          }
        } else {
          this.errorMessage = 'An error occurred during registration. Please try again.';
        }
      }
    });
  }
}
