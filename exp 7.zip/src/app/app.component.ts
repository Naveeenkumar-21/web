import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet, RouterLink, RouterLinkActive } from '@angular/router';
import { UserService } from './services/user.service';
import { CartService } from './services/cart.service';
import { AsyncPipe } from '@angular/common';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet, RouterLink, RouterLinkActive, AsyncPipe],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent implements OnInit {
  title = 'ISO Downloader';
  username = '';
  isLoggedIn = false;
  cartCount = 0;

  constructor(
    private userService: UserService,
    public cartService: CartService
  ) {}

  ngOnInit() {
    this.userService.currentUsername.subscribe(username => {
      this.username = username;
      this.isLoggedIn = !!username;
    });
    
    this.cartService.cartCount$.subscribe(count => {
      this.cartCount = count;
    });
  }

  logout() {
    this.userService.logout();
  }
  
  clearCart() {
    this.cartService.clearCart();
  }
  
  removeFromCart(itemId: string) {
    this.cartService.removeFromCart(itemId);
  }
  
  updateQuantity(itemId: string, quantity: number) {
    this.cartService.updateQuantity(itemId, quantity);
  }
  
  getCartTotal(): number {
    return this.cartService.getCartTotal();
  }
}
