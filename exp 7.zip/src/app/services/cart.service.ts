import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { isPlatformBrowser } from '@angular/common';
import { PLATFORM_ID, Inject } from '@angular/core';

export interface CartItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
}

@Injectable({
  providedIn: 'root'
})
export class CartService {
  private cartItems: CartItem[] = [];
  private cartItemsSubject = new BehaviorSubject<CartItem[]>([]);
  cartItems$ = this.cartItemsSubject.asObservable();
  
  private cartCountSubject = new BehaviorSubject<number>(0);
  cartCount$ = this.cartCountSubject.asObservable();
  private isBrowser: boolean;
  
  constructor(@Inject(PLATFORM_ID) platformId: Object) {
    this.isBrowser = isPlatformBrowser(platformId);
    
    // Load cart from localStorage if exists
    if (this.isBrowser) {
      const savedCart = localStorage.getItem('cart');
      if (savedCart) {
        this.cartItems = JSON.parse(savedCart);
        this.updateCartSubjects();
      }
    }
  }
  
  private updateCartSubjects() {
    this.cartItemsSubject.next([...this.cartItems]);
    
    const totalItems = this.cartItems.reduce((total, item) => {
      return total + item.quantity;
    }, 0);
    
    this.cartCountSubject.next(totalItems);
    
    // Save to localStorage
    if (this.isBrowser) {
      localStorage.setItem('cart', JSON.stringify(this.cartItems));
    }
  }
  
  addToCart(item: Partial<CartItem>) {
    if (!item.id || !item.name || item.price === undefined) {
      console.error('Invalid cart item', item);
      return;
    }
    
    // Check if item already exists in cart
    const existingItemIndex = this.cartItems.findIndex(i => i.id === item.id);
    
    if (existingItemIndex > -1) {
      // Increment quantity if item already exists
      this.cartItems[existingItemIndex].quantity += 1;
    } else {
      // Add as new item
      this.cartItems.push({
        id: item.id,
        name: item.name,
        price: item.price,
        quantity: 1
      });
    }
    
    this.updateCartSubjects();
  }
  
  removeFromCart(itemId: string) {
    this.cartItems = this.cartItems.filter(item => item.id !== itemId);
    this.updateCartSubjects();
  }
  
  updateQuantity(itemId: string, quantity: number) {
    if (quantity <= 0) {
      this.removeFromCart(itemId);
      return;
    }
    
    const itemIndex = this.cartItems.findIndex(item => item.id === itemId);
    if (itemIndex > -1) {
      this.cartItems[itemIndex].quantity = quantity;
      this.updateCartSubjects();
    }
  }
  
  clearCart() {
    this.cartItems = [];
    this.updateCartSubjects();
  }
  
  getCartTotal(): number {
    return this.cartItems.reduce((total, item) => {
      return total + (item.price * item.quantity);
    }, 0);
  }
} 