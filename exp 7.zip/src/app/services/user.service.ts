import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, throwError } from 'rxjs';
import { isPlatformBrowser } from '@angular/common';
import { PLATFORM_ID, Inject } from '@angular/core';
import { ApiService } from './api.service';
import { catchError, tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private usernameSource = new BehaviorSubject<string>('');
  currentUsername = this.usernameSource.asObservable();
  private isBrowser: boolean;

  constructor(
    @Inject(PLATFORM_ID) platformId: Object,
    private apiService: ApiService
  ) {
    this.isBrowser = isPlatformBrowser(platformId);
    
    // Check if user is logged in when service initializes
    if (this.isBrowser) {
      const savedUsername = localStorage.getItem('currentUser');
      if (savedUsername) {
        this.usernameSource.next(savedUsername);
      }
    }
  }

  changeUsername(username: string) {
    // Save username to localStorage for persistence across page refreshes
    if (this.isBrowser) {
      localStorage.setItem('currentUser', username);
    }
    this.usernameSource.next(username);
  }

  logout() {
    // Clear user data from localStorage
    if (this.isBrowser) {
      localStorage.removeItem('currentUser');
    }
    this.usernameSource.next('');
  }

  isLoggedIn(): boolean {
    if (this.isBrowser) {
      return !!localStorage.getItem('currentUser');
    }
    return false;
  }

  // New methods for MongoDB integration
  login(username: string, password: string): Observable<any> {
    return this.apiService.login({ username, password })
      .pipe(
        tap(response => {
          if (response.success) {
            this.changeUsername(username);
          }
        }),
        catchError(error => {
          return throwError(() => error);
        })
      );
  }

  signup(userData: { username: string; email: string; password: string }): Observable<any> {
    return this.apiService.signup(userData)
      .pipe(
        catchError(error => {
          return throwError(() => error);
        })
      );
  }
} 