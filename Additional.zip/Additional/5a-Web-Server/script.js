// Update the time display on the page
function updateTime() {
    const timeElement = document.getElementById('time');
    if (timeElement) {
        const now = new Date();
        const timeString = now.toLocaleTimeString();
        const dateString = now.toLocaleDateString();
        timeElement.textContent = `${dateString} ${timeString}`;
    }
}

// Update the time every second
setInterval(updateTime, 1000);

// Initialize time on page load
document.addEventListener('DOMContentLoaded', () => {
    // Update time initially
    updateTime();
    
    // Add event listeners to navigation links
    const navLinks = document.querySelectorAll('nav a');
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            console.log(`Navigating to: ${link.getAttribute('href')}`);
        });
    });
    
    console.log('Page loaded successfully!');
}); 