# Simple Node.js Web Server

A simple web server built with Node.js native HTTP module to demonstrate serving HTML content.

## Features

- Serves HTML, CSS, JavaScript, and other static files
- Handles different content types
- Provides custom 404 page for missing resources
- Handles server errors
- Simple and lightweight implementation without external dependencies

## Project Structure

```
5a-Web-Server/
├── server.js         # Main server implementation
├── index.html        # Homepage
├── about.html        # About page
├── 404.html          # Custom error page
├── styles.css        # CSS stylesheet
├── script.js         # Client-side JavaScript
└── package.json      # Project configuration
```

## How to Run

1. Make sure you have Node.js installed
2. Clone or download this repository
3. Navigate to the project directory
4. Install dependencies (optional, only needed for nodemon in development):
   ```
   npm install
   ```
5. Start the server:
   ```
   npm start
   ```
   or for development with auto-restart:
   ```
   npm run dev
   ```
6. Open your browser and navigate to `http://localhost:3000`

## Server Implementation

The server is implemented using the following Node.js core modules:
- `http`: For creating the HTTP server and handling requests/responses
- `fs`: For reading files from the file system
- `path`: For working with file and directory paths

The server handles different file types and sets appropriate content types for responses.

## License

MIT